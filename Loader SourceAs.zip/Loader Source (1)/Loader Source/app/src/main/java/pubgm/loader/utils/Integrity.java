package pubgm.loader.utils;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Debug;

import java.security.MessageDigest;
import java.util.Locale;

public class Integrity {

    private static final String EXPECTED_CERT_SHA256 = "77f05d53ce8bf1855caef38ce87f13a8bb2b1b2cdd2d48da9d3ba897eac4549e";

    public static boolean isSignatureValid(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), PackageManager.GET_SIGNATURES);
            Signature[] signatures = info.signatures;
            if (signatures == null || signatures.length == 0) {
                return false;
            }
            for (Signature signature : signatures) {
                String hex = toHex(sha256(signature.toByteArray()));
                if (EXPECTED_CERT_SHA256.equalsIgnoreCase(hex)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isDebuggable(Context context) {
        return (context.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
    }

    public static boolean isDebugger() {
        return Debug.isDebuggerConnected() || Debug.waitingForDebugger();
    }

    public static boolean isTampered(Context context) {
        return !isSignatureValid(context) || isDebuggable(context) || isDebugger();
    }

    private static byte[] sha256(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(data);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format(Locale.US, "%02x", b));
        }
        return sb.toString();
    }
}
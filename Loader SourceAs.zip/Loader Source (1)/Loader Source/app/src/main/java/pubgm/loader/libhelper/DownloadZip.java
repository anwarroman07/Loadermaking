package pubgm.loader.libhelper;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.FileHeader;
import org.lsposed.lsparanoid.Obfuscate;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import pubgm.loader.R;
import pubgm.loader.utils.AnimKit;

@Obfuscate
public class DownloadZip extends AsyncTask<String, Integer, Boolean> {

    private static final int EXTRACT_PHASE = 101;

    private final Context context;
    private Dialog dialog;
    private ProgressBar progressBar;
    private TextView percentText;
    private TextView messageText;
    private final View[] dialogGlowRef = new View[1];

    private native String PASSJKPAPA();

    public DownloadZip(Context context) {
        this.context = context;
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_loading);
        dialog.setCancelable(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        progressBar = dialog.findViewById(R.id.copyProgress);
        percentText = dialog.findViewById(R.id.dialogPercent);
        messageText = dialog.findViewById(R.id.dialogMessage);
        dialog.show();

        View card = dialog.findViewById(R.id.loadingCard);
        if (card != null) {
            AnimKit.zoomIn(card, 360L, 0L);
        }
        View glow = dialog.findViewById(R.id.dialogGlow);
        dialogGlowRef[0] = glow;
        if (glow != null) {
            AnimKit.breathe(glow, 2200L);
        }
    }

    @Override
    protected Boolean doInBackground(String... strings) {
        String downloadUrl = strings[1];
        String fileName = "Loader.zip";
        File pathBase = context.getFilesDir();

        try {
            URL url = new URL(downloadUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            int lengthOfFile = connection.getContentLength();

            InputStream input = connection.getInputStream();
            File outputZip = new File(pathBase, fileName);
            OutputStream output = new FileOutputStream(outputZip);

            byte[] data = new byte[4096];
            int total = 0, count;
            while ((count = input.read(data)) != -1) {
                total += count;
                if (lengthOfFile > 0) {
                    publishProgress((total * 100) / lengthOfFile);
                }
                output.write(data, 0, count);
            }

            output.close();
            input.close();
            connection.disconnect();

            if (!outputZip.exists()) {
                return false;
            }

            publishProgress(EXTRACT_PHASE);
            String password = PASSJKPAPA();
            File loaderDir = new File(pathBase, "loader");
            if (!loaderDir.exists() && !loaderDir.mkdirs()) {
                return false;
            }
            boolean extracted = unzipAndMoveSoFiles(outputZip.getAbsolutePath(), loaderDir.getAbsolutePath(), password);
            outputZip.delete();
            return extracted;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onProgressUpdate(Integer... progress) {
        int p = progress[0];
        if (progressBar == null || percentText == null || messageText == null) {
            return;
        }
        if (p == EXTRACT_PHASE) {
            messageText.setText("Extracting secure assets...");
            percentText.setText("...");
            progressBar.setIndeterminate(true);
            return;
        }
        messageText.setText("Preparing secure environment...");
        progressBar.setIndeterminate(false);
        progressBar.setProgress(p);
        percentText.setText(p + "%");
    }

    @Override
    protected void onPostExecute(Boolean success) {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
        AnimKit.releaseView(dialogGlowRef[0]);
        if (success) {
            Toast.makeText(context, "Loader setup successful!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Failed to setup loader. Check internet connection.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean unzipAndMoveSoFiles(String zipPath, String outputDir, String password) {
        try {
            ZipFile zipFile = new ZipFile(zipPath, password.toCharArray());

            List<FileHeader> fileHeaders = zipFile.getFileHeaders();

            for (FileHeader fileHeader : fileHeaders) {
                String fileName = fileHeader.getFileName();

                if (fileName.endsWith(".so")) {
                    zipFile.extractFile(fileHeader, outputDir);

                    File extractedFile = new File(outputDir, fileName);
                    File targetFile = new File(outputDir, "libbgmi.so");
                    if (extractedFile.exists()) {
                        extractedFile.renameTo(targetFile);
                    }
                }
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
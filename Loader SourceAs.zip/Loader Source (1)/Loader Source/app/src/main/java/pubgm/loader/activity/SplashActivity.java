package pubgm.loader.activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import pubgm.loader.R;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class SplashActivity extends AppCompatActivity {

    private final Handler handler = new Handler();
    private boolean opened;
    private final Runnable fallback = this::openLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(0xFF000000);
        setContentView(R.layout.activity_splash);

        VideoView video = findViewById(R.id.splashVideo);
        ImageView logo = findViewById(R.id.splashLogo);

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(850L).start();

        try {
            String uri = "android.resource://" + getPackageName() + "/" + R.raw.splash_video;
            video.setVideoURI(Uri.parse(uri));
            video.setOnCompletionListener(mp -> openLogin());
            video.setOnErrorListener((mp, what, extra) -> {
                openLogin();
                return true;
            });
            video.start();

            handler.postDelayed(fallback, 12000L);
        } catch (Exception ignored) {
            openLogin();
        }
    }

    private void openLogin() {
        if (opened) {
            return;
        }
        opened = true;
        handler.removeCallbacks(fallback);
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.activity_in, R.anim.activity_out);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(fallback);
    }
}

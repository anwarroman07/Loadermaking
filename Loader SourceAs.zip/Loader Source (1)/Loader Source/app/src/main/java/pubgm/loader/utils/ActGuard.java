package pubgm.loader.utils;

import android.content.Context;

import top.niunaijun.blackbox.core.system.api.WorkConfirmed;

public class ActGuard {

    private static final long REFRESH_WINDOW_MS = 30L * 60L * 1000L;

    public static void onBoot(Context context) {
        try {
            Prefs prefs = new Prefs(context);
            long exp = 0L;
            try {
                exp = Long.parseLong(prefs.getSt("LICENSE_EXP", "0"));
            } catch (Exception ignored) {
            }
            boolean licenseValid = exp == 0L || exp > System.currentTimeMillis();
            long lastCheck = 0L;
            try {
                lastCheck = Long.parseLong(prefs.getSt("SERVER_OK_AT", "0"));
            } catch (Exception ignored) {
            }
            boolean fresh = lastCheck > 0L && (System.currentTimeMillis() - lastCheck) < REFRESH_WINDOW_MS;

            if (licenseValid && fresh) {
                WorkConfirmed.getActivatedStatus();
                restoreCachedStatus();
                return;
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
        WorkConfirmed.activateSdk("UJJWAL-DEMO-01211");
        try {
            new Prefs(context).setSt("SERVER_OK_AT", String.valueOf(System.currentTimeMillis()));
        } catch (Throwable ignored) {
        }
    }

    private static void restoreCachedStatus() {
        try {
            Class<?> nk = Class.forName("android.MetaCore.nk");
            nk.getMethod("loadSavedStatus").invoke(null);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
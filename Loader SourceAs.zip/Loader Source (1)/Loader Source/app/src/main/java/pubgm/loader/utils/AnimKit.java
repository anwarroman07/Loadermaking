package pubgm.loader.utils;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnimKit {

    private static final long AMBIENT_DURATION = 9000L;
    private static final long ROTATE_DURATION = 16000L;

    private static Object currentHost;
    private static final List<Animator> ACTIVE = new ArrayList<>();
    private static final Map<Animator, Object> OWNER = new HashMap<>();

    public static void setHost(Object host) {
        currentHost = host;
    }

    private static void track(Animator a) {
        if (a != null) {
            ACTIVE.add(a);
            OWNER.put(a, currentHost);
        }
    }

    public static void releaseHost(Object host) {
        List<Animator> keep = new ArrayList<>(ACTIVE.size());
        for (Animator a : ACTIVE) {
            Object owner = OWNER.get(a);
            boolean kill = owner == null || owner == host;
            if (kill) {
                try {
                    a.cancel();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                OWNER.remove(a);
            } else {
                keep.add(a);
            }
        }
        ACTIVE.clear();
        ACTIVE.addAll(keep);
    }

    public static void releaseAll() {
        for (Animator a : ACTIVE) {
            try {
                a.cancel();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
        ACTIVE.clear();
        OWNER.clear();
    }

    public static void releaseView(View v) {
        if (v == null) {
            return;
        }
        List<Animator> keep = new ArrayList<>(ACTIVE.size());
        for (Animator a : ACTIVE) {
            boolean kill = (a instanceof ObjectAnimator) && ((ObjectAnimator) a).getTarget() == v;
            if (kill) {
                try {
                    a.cancel();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                OWNER.remove(a);
            } else {
                keep.add(a);
            }
        }
        ACTIVE.clear();
        ACTIVE.addAll(keep);
    }

    private static void hw(View v) {
        if (v != null && v.getLayerType() != View.LAYER_TYPE_HARDWARE) {
            v.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
    }

    public static ViewPropertyAnimator fadeSlideIn(View v, long duration, long delay, float startDyPx) {
        v.setAlpha(0f);
        v.setTranslationY(startDyPx);
        return v.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(duration)
                .setStartDelay(delay)
                .setInterpolator(new DecelerateInterpolator(1.6f));
    }

    public static ViewPropertyAnimator zoomIn(View v, long duration, long delay) {
        v.setAlpha(0f);
        v.setScaleX(0.65f);
        v.setScaleY(0.65f);
        return v.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(duration)
                .setStartDelay(delay)
                .setInterpolator(new OvershootInterpolator(1.3f));
    }

    public static ViewPropertyAnimator slideRightIn(View v, long duration, long delay) {
        v.setAlpha(0f);
        v.setTranslationX(48f);
        return v.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(duration)
                .setStartDelay(delay)
                .setInterpolator(new DecelerateInterpolator(1.6f));
    }

    public static void ambientAurora(final View v, float driftPx) {
        hw(v);
        v.setTranslationX(-driftPx);
        ObjectAnimator x = ObjectAnimator.ofFloat(v, "translationX", -driftPx, driftPx);
        x.setDuration(AMBIENT_DURATION);
        x.setRepeatCount(ValueAnimator.INFINITE);
        x.setRepeatMode(ValueAnimator.REVERSE);
        x.setInterpolator(new DecelerateInterpolator(1.2f));
        x.start();
        track(x);

        ObjectAnimator s = ObjectAnimator.ofFloat(v, "scaleX", 1f, 1.15f, 1f);
        s.setDuration(AMBIENT_DURATION);
        s.setRepeatCount(ValueAnimator.INFINITE);
        s.setRepeatMode(ValueAnimator.REVERSE);
        s.setInterpolator(new DecelerateInterpolator(1.2f));
        s.start();
        track(s);

        ObjectAnimator sy = ObjectAnimator.ofFloat(v, "scaleY", 1f, 1.15f, 1f);
        sy.setDuration(AMBIENT_DURATION);
        sy.setRepeatCount(ValueAnimator.INFINITE);
        sy.setRepeatMode(ValueAnimator.REVERSE);
        sy.setInterpolator(new DecelerateInterpolator(1.2f));
        sy.start();
        track(sy);
    }

    public static void ambientAuroraDrift(final View v, float dx, float dy) {
        hw(v);
        v.setTranslationX(-dx);
        v.setTranslationY(-dy);
        ObjectAnimator x = ObjectAnimator.ofFloat(v, "translationX", -dx, dx);
        x.setDuration(AMBIENT_DURATION + 1500L);
        x.setRepeatCount(ValueAnimator.INFINITE);
        x.setRepeatMode(ValueAnimator.REVERSE);
        x.start();
        track(x);
        ObjectAnimator y = ObjectAnimator.ofFloat(v, "translationY", -dy, dy);
        y.setDuration(AMBIENT_DURATION - 1000L);
        y.setRepeatCount(ValueAnimator.INFINITE);
        y.setRepeatMode(ValueAnimator.REVERSE);
        y.start();
        track(y);
    }

    public static void rotateInfinitely(View v, long duration) {
        hw(v);
        ObjectAnimator r = ObjectAnimator.ofFloat(v, "rotation", 0f, 360f);
        r.setDuration(duration);
        r.setRepeatCount(ValueAnimator.INFINITE);
        r.setInterpolator(new android.view.animation.LinearInterpolator());
        r.start();
        track(r);
    }

    public static void pulse(final View v, long duration) {
        hw(v);
        PropertyValuesHolder sx = PropertyValuesHolder.ofFloat("scaleX", 1f, 1.25f);
        PropertyValuesHolder sy = PropertyValuesHolder.ofFloat("scaleY", 1f, 1.25f);
        PropertyValuesHolder a = PropertyValuesHolder.ofFloat("alpha", 1f, 0.55f);
        ObjectAnimator anim = ObjectAnimator.ofPropertyValuesHolder(v, sx, sy, a);
        anim.setDuration(duration);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setRepeatMode(ValueAnimator.REVERSE);
        anim.start();
        track(anim);
    }

    public static void breathe(final View v, long duration) {
        hw(v);
        PropertyValuesHolder sx = PropertyValuesHolder.ofFloat("scaleX", 1f, 1.06f);
        PropertyValuesHolder sy = PropertyValuesHolder.ofFloat("scaleY", 1f, 1.06f);
        ObjectAnimator anim = ObjectAnimator.ofPropertyValuesHolder(v, sx, sy);
        anim.setDuration(duration);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setRepeatMode(ValueAnimator.REVERSE);
        anim.start();
        track(anim);
    }

    public static ViewPropertyAnimator bounce(final View v, long duration) {
        return v.animate()
                .scaleX(0.94f).scaleY(0.94f).alpha(0.2f)
                .setDuration(duration);
    }

    public static void pressScale(final View v) {
        v.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(110).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(180)
                            .setInterpolator(new OvershootInterpolator(1.1f)).start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    public static void gradientText(final TextView tv, final int colorStart, final int colorMid, final int colorEnd) {
        tv.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int w = tv.getWidth();
                int h = tv.getHeight();
                if (w <= 0 || h <= 0) {
                    return;
                }
                tv.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                LinearGradient g = new LinearGradient(0, 0, w, 0,
                        new int[]{colorStart, colorMid, colorEnd}, null, Shader.TileMode.CLAMP);
                tv.getPaint().setShader(g);
                tv.invalidate();
            }
        });
    }
}
package pubgm.loader.utils;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Locale;

public class LicenseTime {

    private static final long UNIX_SECONDS = 100000000L;
    private static final long DAYS_BOUNDARY = 36600L;
    private static final long DAY_MS = 86400000L;

    public static long parseEpochMs(String rawJson) {
        if (rawJson == null || rawJson.isEmpty() || "0".equals(rawJson)) {
            return 0L;
        }
        try {
            JSONObject root = new JSONObject(rawJson);
            long best = scan(root);
            if (best == 0L && root.has("data")) {
                best = scan(root.optJSONObject("data"));
            }
            return best;
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private static long scan(JSONObject o) {
        long best = 0L;
        if (o == null) {
            return 0L;
        }
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String key = it.next();
            if (!isTimeKey(key)) {
                continue;
            }
            long v = classify(o.opt(key));
            if (v > best) {
                best = v;
            }
        }
        return best;
    }

    private static boolean isTimeKey(String rawKey) {
        String k = rawKey.toLowerCase(Locale.US);
        if (k.contains("timestamp") || k.contains("rng") || k.contains("now")
                || k.contains("created") || k.contains("updated") || k.equals("token")) {
            return false;
        }
        return k.contains("day") || k.contains("expire") || k.contains("expiry")
                || k.equals("exp") || k.contains("endtime") || k.contains("end_time")
                || k.contains("until") || k.contains("valid") || k.contains("duration")
                || k.contains("time") || k.contains("plan") || k.contains("subscription")
                || k.contains("remain") || k.contains("left") || k.contains("end");
    }

    private static long classify(Object val) {
        if (val == null) {
            return 0L;
        }
        if (val instanceof Number) {
            return classifyLong(((Number) val).longValue());
        }
        if (val instanceof String) {
            return classifyString(((String) val).trim());
        }
        return 0L;
    }

    private static long classifyString(String s) {
        if (s.isEmpty()) {
            return 0L;
        }
        try {
            return classifyLong(Long.parseLong(s));
        } catch (Exception ignored) {
        }
        long d = parseDate(s);
        if (d != 0L) {
            return d;
        }
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+")
                .matcher(s);
        if (m.find()) {
            try {
                return classifyLong(Long.parseLong(m.group()));
            } catch (Exception ignored) {
            }
        }
        return 0L;
    }

    private static long parseDate(String s) {
        String[] formats = {"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "dd/MM/yyyy HH:mm:ss",
                "dd/MM/yyyy", "MM/dd/yyyy", "dd-MM-yyyy", "yyyy/MM/dd"};
        for (String f : formats) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(f, Locale.US);
                sdf.setLenient(false);
                java.util.Date d = sdf.parse(s);
                if (d != null) {
                    return d.getTime();
                }
            } catch (Exception ignored) {
            }
        }
        return 0L;
    }

    private static long classifyLong(long v) {
        long now = System.currentTimeMillis();
        if (v <= 0L) {
            return 0L;
        }
        if (v >= UNIX_SECONDS) {
            return v * 1000L;
        }
        if (v > DAYS_BOUNDARY) {
            return now + v * 1000L;
        }
        return now + v * DAY_MS;
    }

    public static String format(long ms) {
        if (ms <= 0L) {
            return "00d 00:00:00";
        }
        long secs = ms / 1000L;
        long days = secs / 86400L;
        secs %= 86400L;
        long h = secs / 3600L;
        secs %= 3600L;
        long m = secs / 60L;
        long s = secs % 60L;
        return String.format(Locale.US, "%02dd %02d:%02d:%02d", days, h, m, s);
    }
}
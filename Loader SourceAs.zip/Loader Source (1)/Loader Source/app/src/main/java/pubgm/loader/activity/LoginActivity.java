package pubgm.loader.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import pubgm.loader.R;
import pubgm.loader.utils.AnimKit;
import pubgm.loader.utils.Integrity;
import pubgm.loader.utils.LicenseTime;
import pubgm.loader.utils.Prefs;
import org.lsposed.lsparanoid.Obfuscate;
import pubgm.loader.libhelper.DownloadZip;

@Obfuscate
public class LoginActivity extends AppCompatActivity {

    static {
        try {
            System.loadLibrary("ujjwal");
        } catch (UnsatisfiedLinkError ignored) {
        }
    }

    private static final int REQUEST_MANAGE_STORAGE_PERMISSION = 100;
    private static final int REQUEST_MANAGE_UNKNOWN_APP_SOURCES = 200;
    private static final String PREFS_NAME = "com.sameer.arora.prefs";
    private static final String PREF_PERMISSIONS_GRANTED = "permissions_granted";

    public static String USERKEY;
    private Button btnSignIn;
    private AlertDialog loadingDialog;
    private EditText userkeyField;

    public static native String FixCrash();
    public native String logo();
    public static native String Expiry();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Integrity.isTampered(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("BLOCKED")
                    .setMessage("This build is modified. Please use the official app.")
                    .setCancelable(false)
                    .setPositiveButton("Exit", (dialog, which) -> Process.killProcess(Process.myPid()))
                    .show();
            return;
        }

        setContentView(R.layout.activity_login);

        checkAndRequestPermissions();
        initDesign();
        new DownloadZip(LoginActivity.this).execute("1", FixCrash());
    }

    @Override
    protected void onStart() {
        super.onStart();
        AnimKit.setHost(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        AnimKit.releaseHost(this);
    }

    private void checkAndRequestPermissions() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean permissionsGranted = prefs.getBoolean(PREF_PERMISSIONS_GRANTED, false);

        if (!isStoragePermissionGranted()) {
            requestStoragePermissionDirect();
        } else if (!canRequestPackageInstalls()) {
            requestUnknownAppPermissionsDirect();
        } else {
            prefs.edit().putBoolean(PREF_PERMISSIONS_GRANTED, true).apply();
        }
    }

    private boolean isStoragePermissionGranted() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager();
    }

    private void requestStoragePermissionDirect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            startActivityForResult(intent, REQUEST_MANAGE_STORAGE_PERMISSION);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_MANAGE_STORAGE_PERMISSION);
        }
    }

    private boolean canRequestPackageInstalls() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getPackageManager().canRequestPackageInstalls();
    }

    private void requestUnknownAppPermissionsDirect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_MANAGE_UNKNOWN_APP_SOURCES);
        }
    }

    private void initDesign() {
        Prefs prefs = new Prefs(this);
        userkeyField = findViewById(R.id.userkey);
        userkeyField.setText(prefs.getSt("USER", ""));

        btnSignIn = findViewById(R.id.login);
        AnimKit.pressScale(btnSignIn);
        btnSignIn.setOnClickListener(v -> {
            String userKey = userkeyField.getText().toString().trim();
            if (!userKey.isEmpty()) {
                prefs.setSt("USER", userKey);
                USERKEY = userKey;
                login(userKey);
            } else {
                userkeyField.setError("Please Enter Your License");
            }
        });

        ImageView paste = findViewById(R.id.paste);
        if (paste != null) {
            paste.setOnClickListener(view -> {
                ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboardManager != null && clipboardManager.getPrimaryClip() != null && clipboardManager.getPrimaryClip().getItemCount() > 0) {
                    String pastedText = clipboardManager.getPrimaryClip().getItemAt(0).getText().toString();
                    if (pastedText.length() > 5) {
                        userkeyField.setText(pastedText);
                    } else {
                        Toast.makeText(this, "Invalid key in clipboard.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "No text in clipboard.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        TextView getKey = findViewById(R.id.GetKey);
        if (getKey != null) {
            getKey.setOnClickListener(view -> Toast.makeText(this, "Contact support for a key.", Toast.LENGTH_SHORT).show());
        }
    }

    private void showLoadingDialog(String errorMessage) {
        if (loadingDialog == null) {
            loadingDialog = new AlertDialog.Builder(this).setView(R.layout.ios_loading).create();
            loadingDialog.setCancelable(false);
            if (loadingDialog.getWindow() != null) {
                loadingDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            }
        }
        loadingDialog.show();

        ProgressBar progressBar = loadingDialog.findViewById(R.id.progressBar);
        TextView loadingText = loadingDialog.findViewById(R.id.loadingText);
        TextView progressText = loadingDialog.findViewById(R.id.progressText);
        Button okButton = loadingDialog.findViewById(R.id.okButton);
        ImageView loadingIcon = loadingDialog.findViewById(R.id.loadingIcon);

        if (errorMessage != null && !errorMessage.isEmpty()) {
            if (progressBar != null) progressBar.setVisibility(ProgressBar.GONE);
            if (loadingIcon != null) loadingIcon.setVisibility(ImageView.GONE);
            if (loadingText != null) {
                loadingText.setVisibility(TextView.VISIBLE);
                loadingText.setText("ERROR");
            }
            if (progressText != null) {
                progressText.setVisibility(TextView.VISIBLE);
                progressText.setText(errorMessage);
            }
            if (okButton != null) {
                okButton.setVisibility(Button.VISIBLE);
                okButton.setOnClickListener(v -> dismissLoadingDialog());
            }
        } else {
            if (loadingIcon != null) loadingIcon.setVisibility(ImageView.VISIBLE);
            if (progressBar != null) progressBar.setVisibility(ProgressBar.VISIBLE);
            if (loadingText != null) {
                loadingText.setVisibility(TextView.VISIBLE);
                loadingText.setText("Logging in...");
            }
            if (progressText != null) {
                progressText.setVisibility(TextView.VISIBLE);
                progressText.setText("Please wait...");
            }
            if (okButton != null) okButton.setVisibility(Button.GONE);
        }
    }

    private void dismissLoadingDialog() {
        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
    }

    private void login(String userKey) {
        showLoadingDialog(null);

        Handler loginHandler = new Handler(msg -> {
            dismissLoadingDialog();
            if (msg.what == 0) { // Login successful
                String raw = null;
                try {
                    raw = Expiry();
                } catch (Throwable t) {
                    raw = null;
                }
                long exp = LicenseTime.parseEpochMs(raw);
                new Prefs(LoginActivity.this).setSt("LICENSE_EXP", String.valueOf(exp));
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                Toast.makeText(this, "Login Success", Toast.LENGTH_SHORT).show();
                finish(); // Close LoginActivity
            } else if (msg.what == 1) { // Login failed
                String errorMessage = (String) msg.obj;
                showLoadingDialog(errorMessage); // Display error message in the dialog
            }
            return true;
        });

        new Thread(() -> {
            String result = native_Check(this, userKey);
            if ("OK".equals(result)) {
                loginHandler.sendEmptyMessage(0); // Notify success
            } else {
                Message msg = Message.obtain();
                msg.what = 1; // Notify failure
                msg.obj = result; // Pass the error message
                loginHandler.sendMessage(msg);
            }
        }).start();
    }

    private static native String native_Check(Context context, String userKey);

    private static native String activity();

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_MANAGE_STORAGE_PERMISSION) {
            if (isStoragePermissionGranted()) {
                checkAndRequestPermissions();
            } else {
                checkAndRequestPermissions();
            }
        } else if (requestCode == REQUEST_MANAGE_UNKNOWN_APP_SOURCES) {
            if (canRequestPackageInstalls()) {
                Process.killProcess(Process.myPid());
            }
        }
    }
}

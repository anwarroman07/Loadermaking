package pubgm.loader.utils;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;

import java.util.Locale;
import android.util.Base64;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class Prefs {
    public Context context;
    SharedPreferences sp;

    private static final String ENC_KEY = "kAlwA!_2019";
    private static final String ENC_PREFIX = "K1E|";

    public Prefs(Context context){
        this.context = context;
        sp = context.getSharedPreferences("settings",Context.MODE_PRIVATE);
    }

    public String getSt(String  map,String ori){
        String raw = sp.getString(map, ori);
        if (raw == null || !raw.startsWith(ENC_PREFIX)) {
            return raw == null ? ori : raw;
        }
        String dec = dec(raw);
        return dec != null ? dec : raw;
    }

    public void setSt(String  map,String write){
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(map, enc(write));
        ed.apply();
        ed.commit();
    }

    private static String enc(String value) {
        String xored = xor(value);
        return ENC_PREFIX + Base64.encodeToString(xored.getBytes(), Base64.NO_WRAP);
    }

    private static String dec(String value) {
        try {
            String body = value.substring(ENC_PREFIX.length());
            String xored = new String(Base64.decode(body, Base64.NO_WRAP));
            return xor(xored);
        } catch (Exception e) {
            return null;
        }
    }

    private static String xor(String value) {
        char[] data = value.toCharArray();
        for (int i = 0; i < data.length; i++) {
            data[i] ^= ENC_KEY.charAt(i % ENC_KEY.length());
        }
        return new String(data);
    }

    public boolean getBool(String  map,boolean ori){
        return sp.getBoolean(map,ori);
    }
    public void setBool(String  map,boolean write){
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(map,write);
        ed.apply();
        ed.commit();
    }

    public int getInt(String  map,int ori){
        return sp.getInt(map,ori);
    }

    public void setInt(String  map,int write){
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(map,write);
        ed.apply();
        ed.commit();
    }

    public void setBool(String file,String map, boolean write) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(file,Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sharedPreferences.edit();
        ed.putBoolean(map, write);
        ed.apply();
        ed.commit();
    }

    public void setSt(String file,String map, String write) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(file,Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sharedPreferences.edit();
        ed.putString(map, write);
        ed.apply();
        ed.commit();
    }
    public String getSt(String file,String  map, String ori){
        SharedPreferences sharedPreferences = context.getSharedPreferences(file,Context.MODE_PRIVATE);
        return sharedPreferences.getString(map,ori);
    }

    public void setInt(String file,String map, int write) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(file,Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sharedPreferences.edit();
        ed.putInt(map, write);
        ed.apply();
        ed.commit();
    }

    public int getInt(String file,String  map, int ori){
        SharedPreferences sharedPreferences = context.getSharedPreferences(file,Context.MODE_PRIVATE);
        return sharedPreferences.getInt(map,ori);
    }


    public void setLocale(Activity act, String cd) {
        Locale loc = new Locale(cd);
        loc.setDefault(loc);
        Resources ress = act.getResources();
        Configuration cfg = ress.getConfiguration();
        cfg.setLocale(loc);
        ress.updateConfiguration(cfg, ress.getDisplayMetrics());
    }
    public void setLocale(Service act, String cd) {
        Locale loc = new Locale(cd);
        loc.setDefault(loc);
        Resources ress = act.getResources();
        Configuration cfg = ress.getConfiguration();
        cfg.setLocale(loc);
        ress.updateConfiguration(cfg, ress.getDisplayMetrics());
    }

}

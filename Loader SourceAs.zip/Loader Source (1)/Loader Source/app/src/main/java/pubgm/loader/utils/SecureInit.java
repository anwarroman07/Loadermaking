package pubgm.loader.utils;

import android.app.Activity;
import android.app.Dialog;
import android.os.AsyncTask;
import android.view.View;
import android.widget.TextView;

import pubgm.loader.R;
import top.niunaijun.blackbox.BlackBoxCore;

public class SecureInit {

    public static void run(final Activity activity, final Runnable onReady) {
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.dialog_loading);
        dialog.setCancelable(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        TextView msg = dialog.findViewById(R.id.dialogMessage);
        if (msg != null) {
            msg.setText("Initializing secure environment...");
        }
        final View[] dialogGlowRef = new View[1];

        new AsyncTask<Void, Void, Void>() {
            @Override
            protected void onPreExecute() {
                View card = dialog.findViewById(R.id.loadingCard);
                if (card != null) {
                    AnimKit.zoomIn(card, 360L, 0L);
                }
                View glow = dialog.findViewById(R.id.dialogGlow);
                dialogGlowRef[0] = glow;
                if (glow != null) {
                    AnimKit.breathe(glow, 2200L);
                }
                dialog.show();
            }

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    BlackBoxCore.get().doCreate();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
                AnimKit.releaseView(dialogGlowRef[0]);
                if (onReady != null) {
                    onReady.run();
                }
            }
        }.execute();
    }
}
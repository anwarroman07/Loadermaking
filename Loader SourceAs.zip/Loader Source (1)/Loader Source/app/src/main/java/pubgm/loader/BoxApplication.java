package pubgm.loader;
import org.lsposed.lsparanoid.Obfuscate;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import pubgm.loader.utils.FPrefs;
import pubgm.loader.utils.ActGuard;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.AppLifecycleCallback;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

@Obfuscate
public class BoxApplication extends Application {

    private void installCrashLogger() {
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (dir != null && (dir.exists() || dir.mkdirs())) {
                    File out = new File(dir, "loader_crash.txt");
                    boolean append = out.exists() && out.length() < (1024L * 1024L);
                    PrintWriter pw = new PrintWriter(new FileWriter(out, append));
                    pw.println("==== CRASH " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + " ====");
                    pw.println("thread=" + thread.getName());
                    pw.println("sdk=" + Build.VERSION.SDK_INT + " dev=" + Build.DEVICE + " model=" + Build.MODEL);
                    throwable.printStackTrace(pw);
                    pw.flush();
                    pw.close();
                }
            } catch (Throwable ignored) {
            }
            try {
                android.os.Process.killProcess(android.os.Process.myPid());
            } catch (Throwable ignored) {
            }
        });
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        FPrefs prefs = FPrefs.with(base);
        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {

                @Override
                public String getHostPackageName() {
                    return base.getPackageName();
                }

                @Override
                public boolean setHideRoot() {
                    return true;
                }

                @Override
                public boolean isEnableDaemonService(){
                    return false;
                }

                public boolean requestInstallPackage(File file){
                    PackageInfo packageInfo = base.getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(),0);
                    return false;
                }

            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        installCrashLogger();
        try {
            BlackBoxCore.get().doCreate();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        ActGuard.onBoot(this);
        BlackBoxCore.get().addAppLifecycleCallback(new AppLifecycleCallback(){

            public void beforeCreateApplication(){
                String packageName;
                String processName;
                Context context;
                int userId;
            }

            public void beforeApplicationOnCreate(){
                String packageName;
                String processName;
                Application application;
                int userId;
            }

            public void afterApplicationOnCreate(){
                String packageName;
                String processName;
                Application application;
                int userId;
            }

        });
    }

}

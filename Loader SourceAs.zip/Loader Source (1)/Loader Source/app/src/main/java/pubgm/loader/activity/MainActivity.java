package pubgm.loader.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import pubgm.loader.R;
import pubgm.loader.utils.AnimKit;
import pubgm.loader.utils.Prefs;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
import pubgm.loader.libhelper.FileCopyTask;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class MainActivity extends AppCompatActivity {

    private static final String BGMI_PACKAGE = "com.pubg.imobile";
    private static final int USER_ID = 0;

    private BlackBoxCore blackBoxCore;
    private FileCopyTask fileCopyTask;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        blackBoxCore = BlackBoxCore.get();
        try {
            blackBoxCore.doCreate();
        } catch (Throwable t) {
            t.printStackTrace();
        }

        updateExpiryDate();
        updateUserKey();

        getWindow().setStatusBarColor(getColor(R.color.background));

        fileCopyTask = new FileCopyTask(this);

        Button startButton = findViewById(R.id.startBgmi);
        startButton.setOnClickListener(v -> handleStart());
        AnimKit.pressScale(startButton);

        attachPress(findViewById(R.id.headerCard));
        attachPress(findViewById(R.id.sessionCard));
        attachPress(findViewById(R.id.versionCard));
        attachPress(findViewById(R.id.licenseCard));
        attachPress(findViewById(R.id.expiryCard));
        attachPress(findViewById(R.id.systemCard));
        attachPress(findViewById(R.id.updateCard));
    }

    private void attachPress(View v) {
        if (v != null) {
            AnimKit.pressScale(v);
        }
    }

    private void updateExpiryDate() {
        TextView expiryView = findViewById(R.id.expiryDate);
        if (expiryView == null) {
            return;
        }
        try {
            String raw = new Prefs(this).getSt("LICENSE_EXP", "0");
            long exp = Long.parseLong(raw);
            if (exp <= 0) {
                expiryView.setText("Lifetime");
                return;
            }
            SimpleDateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            SimpleDateFormat outFormat = new SimpleDateFormat("dd MMM yyyy", Locale.US);
            expiryView.setText(outFormat.format(new Date(exp)));
        } catch (Exception e) {
            expiryView.setText("—");
        }
    }

    private void updateUserKey() {
        TextView keyView = findViewById(R.id.userKeyDisplay);
        if (keyView == null) {
            return;
        }
        String savedKey = new Prefs(this).getSt("USER", "");
        if (savedKey != null && !savedKey.trim().isEmpty()) {
            keyView.setText(savedKey.trim());
        } else {
            keyView.setText("—");
        }
    }

    private void showStartOptions() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(R.layout.dialog_start_options)
                .create();

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            }
            Button launchButton = dialog.findViewById(R.id.optionLaunch);
            Button copyButton = dialog.findViewById(R.id.optionCopyObb);
            Button clearButton = dialog.findViewById(R.id.optionClearLogin);
            TextView closeButton = dialog.findViewById(R.id.optionClose);

            if (launchButton != null) {
                launchButton.setOnClickListener(v -> {
                    dialog.dismiss();
                    copyObbFilesAndLaunch();
                });
            }
            if (copyButton != null) {
                copyButton.setOnClickListener(v -> {
                    dialog.dismiss();
                    copyObbFilesAndLaunch();
                });
            }
            if (clearButton != null) {
                clearButton.setOnClickListener(v -> {
                    dialog.dismiss();
                    handleClearLogin();
                });
            }
            if (closeButton != null) {
                closeButton.setOnClickListener(v -> dialog.dismiss());
            }
        });

        dialog.show();
    }

    private void handleStart() {
        if (blackBoxCore.isInstalled(BGMI_PACKAGE, USER_ID)) {
            showStartOptions();
        } else {
            installGame();
        }
    }

    private void installGame() {
        Toast.makeText(this, "Installing BGMI...", Toast.LENGTH_SHORT).show();
        InstallResult installResult = blackBoxCore.installPackageAsUser(BGMI_PACKAGE, USER_ID);

        if (installResult.success) {
            Toast.makeText(this, "BGMI Installed Successfully!", Toast.LENGTH_SHORT).show();
            copyObbFilesAndLaunch();
        } else {
            Toast.makeText(this, "Installation Failed: " + installResult.msg, Toast.LENGTH_SHORT).show();
        }
    }

    private void copyObbFilesAndLaunch() {
        fileCopyTask.copyObbFolderAsync(BGMI_PACKAGE, success -> {
            if (success) {
                Toast.makeText(this, "OBB copied successfully!", Toast.LENGTH_SHORT).show();
                launchGame();
            } else {
                Toast.makeText(this, "Failed to copy OBB!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void launchGame() {
        boolean success = blackBoxCore.launchApk(BGMI_PACKAGE, USER_ID);
        if (success) {
            Toast.makeText(this, "BGMI launched successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to launch BGMI!", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleClearLogin() {
        try {
            blackBoxCore.stopPackage(BGMI_PACKAGE, USER_ID);
            blackBoxCore.clearPackage(BGMI_PACKAGE, USER_ID);
            Toast.makeText(this, "Login data cleared.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to clear: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AnimKit.releaseAll();
        if (blackBoxCore != null) {
            try {
                blackBoxCore.uninstallPackageAsUser(BGMI_PACKAGE, USER_ID);
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }
}

# ---- JNI: native code resolves these classes/methods BY NAME ----
-keep class pubgm.loader.activity.LoginActivity { *; }
-keep class pubgm.loader.libhelper.DownloadZip { *; }
-keep class pubgm.loader.BoxApplication { *; }
-keep class pubgm.loader.activity.MainActivity { *; }

# ---- Integrity & token storage (hard requirements) ----
-keep class pubgm.loader.utils.Integrity { *; }
-keep class pubgm.loader.utils.Prefs { *; }

# ---- BlackBox VM runtime (heavy reflection) ----
-keep class top.niunaijun.blackbox.** { *; }
-keep class black.** { *; }

# ---- Deferred callbacks used via reflection in UiKit/ActivityCompat ----
-keep class org.jdeferred.** { *; }
-dontwarn org.jdeferred.**
-dontwarn javax.annotation.**

# ---- SLF4J transitive logging ----
-keep class org.slf4j.** { *; }
-dontwarn org.slf4j.**

# ---- keep resource class & all annotations alive ----
-keep class pubgm.loader.R { *; }
-keep class pubgm.loader.R$* { *; }
-keepattributes *Annotation*
-keepattributes Signature, InnerClasses, EnclosingMethod, RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations, RuntimeInvisibleAnnotations, RuntimeInvisibleParameterAnnotations

-allowaccessmodification